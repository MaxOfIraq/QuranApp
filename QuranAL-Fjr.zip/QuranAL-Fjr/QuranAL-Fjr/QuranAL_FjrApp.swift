//
//  QuranAL_FjrApp.swift
//  QuranAL-Fjr
//
//  Created by Ahmed Salah on 01/11/2024.
//

import SwiftUI

@main
struct QuranAL_FjrApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
