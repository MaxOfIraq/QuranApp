//
//  ContentView.swift
//  QuranAL-Fjr
//
//  Created by Ahmed Salah on 01/11/2024.
//

import SwiftUI

struct Surah: Identifiable {
    let id = UUID()
    let name: String
    let imageRange: Range<Int>
}
let surahs = [
    Surah(name: "الفاتحة", imageRange: 1..<2),
    Surah(name: "البقرة", imageRange: 1..<51),
    Surah(name: "آل عمران", imageRange: 51..<55),
    Surah(name: "النساء", imageRange: 55..<60),
    Surah(name: "المائدة", imageRange: 60..<65),
    Surah(name: "الأنعام", imageRange: 65..<72),
    Surah(name: "الأعراف", imageRange: 72..<80),
    Surah(name: "الأنفال", imageRange: 80..<83),
    Surah(name: "التوبة", imageRange: 83..<88),
    Surah(name: "يونس", imageRange: 88..<94),
    Surah(name: "هود", imageRange: 94..<99),
    Surah(name: "يوسف", imageRange: 99..<106),
    Surah(name: "الرعد", imageRange: 106..<111),
    Surah(name: "إبراهيم", imageRange: 111..<116),
    Surah(name: "الحجر", imageRange: 116..<120),
    Surah(name: "النحل", imageRange: 120..<130),
    Surah(name: "الإسراء", imageRange: 130..<136),
    Surah(name: "الكهف", imageRange: 136..<145),
    Surah(name: "مريم", imageRange: 145..<150),
    Surah(name: "طه", imageRange: 150..<156),
    Surah(name: "الأنبياء", imageRange: 156..<162),
    Surah(name: "الحج", imageRange: 162..<169),
    Surah(name: "المؤمنون", imageRange: 169..<174),
    Surah(name: "النور", imageRange: 174..<180),
    Surah(name: "الفرقان", imageRange: 180..<186),
    Surah(name: "الشعراء", imageRange: 186..<194),
    Surah(name: "النمل", imageRange: 194..<199),
    Surah(name: "القصص", imageRange: 199..<206),
    Surah(name: "العنكبوت", imageRange: 206..<212),
    Surah(name: "الروم", imageRange: 212..<217),
    Surah(name: "لقمان", imageRange: 217..<221),
    Surah(name: "السجدة", imageRange: 221..<225),
    Surah(name: "الأحزاب", imageRange: 225..<232),
    Surah(name: "سبأ", imageRange: 232..<237),
    Surah(name: "فاطر", imageRange: 237..<243),
    Surah(name: "يس", imageRange: 243..<250),
    Surah(name: "الصافات", imageRange: 250..<256),
    Surah(name: "ص", imageRange: 256..<261),
    Surah(name: "الزمر", imageRange: 261..<268),
    Surah(name: "غافر", imageRange: 268..<274),
    Surah(name: "فصلت", imageRange: 274..<279),
    Surah(name: "الشورى", imageRange: 279..<284),
    Surah(name: "الزخرف", imageRange: 284..<290),
    Surah(name: "الدخان", imageRange: 290..<294),
    Surah(name: "الجاثية", imageRange: 294..<298),
    Surah(name: "الأحقاف", imageRange: 298..<303),
    Surah(name: "محمد", imageRange: 303..<307),
    Surah(name: "الفتح", imageRange: 307..<311),
    Surah(name: "الحجرات", imageRange: 311..<315),
    Surah(name: "ق", imageRange: 315..<319),
    Surah(name: "الذاريات", imageRange: 319..<324),
    Surah(name: "الطور", imageRange: 324..<328),
    Surah(name: "النجم", imageRange: 328..<332),
    Surah(name: "القمر", imageRange: 332..<337),
    Surah(name: "الرحمن", imageRange: 337..<341),
    Surah(name: "الواقعة", imageRange: 341..<346),
    Surah(name: "الحديد", imageRange: 346..<350),
    Surah(name: "المجادلة", imageRange: 350..<354),
    Surah(name: "الحشر", imageRange: 354..<358),
    Surah(name: "الممتحنة", imageRange: 358..<362),
    Surah(name: "التغابن", imageRange: 362..<367),
    Surah(name: "الطلاق", imageRange: 367..<371),
    Surah(name: "التحريم", imageRange: 371..<374),
    Surah(name: "الملك", imageRange: 374..<378),
    Surah(name: "القلم", imageRange: 378..<383),
    Surah(name: "الحاقة", imageRange: 383..<387),
    Surah(name: "المعارج", imageRange: 387..<391),
    Surah(name: "نوح", imageRange: 391..<395),
    Surah(name: "الجن", imageRange: 395..<399),
    Surah(name: "المُزمل", imageRange: 399..<403),
    Surah(name: "المدثر", imageRange: 403..<407),
    Surah(name: "القيامة", imageRange: 407..<411),
    Surah(name: "الإنسان", imageRange: 411..<416),
    Surah(name: "المرسلات", imageRange: 416..<421),
    Surah(name: "النبأ", imageRange: 421..<425),
    Surah(name: "النازعات", imageRange: 425..<429),
    Surah(name: "عبس", imageRange: 429..<433),
    Surah(name: "التكوير", imageRange: 433..<436),
    Surah(name: "الانفطار", imageRange: 436..<439),
    Surah(name: "المطففين", imageRange: 439..<444),
    Surah(name: "الانشقاق", imageRange: 444..<448),
    Surah(name: "البروج", imageRange: 448..<452),
    Surah(name: "الطارق", imageRange: 452..<455),
    Surah(name: "الأعلى", imageRange: 455..<459),
    Surah(name: "الغاشية", imageRange: 459..<462),
    Surah(name: "الفجر", imageRange: 462..<465),
    Surah(name: "البلد", imageRange: 465..<468),
    Surah(name: "الشمس", imageRange: 468..<471),
    Surah(name: "الليل", imageRange: 471..<474),
    Surah(name: "الضحى", imageRange: 474..<477),
    Surah(name: "الشرح", imageRange: 477..<480),
    Surah(name: "التين", imageRange: 480..<483),
    Surah(name: "العلق", imageRange: 483..<486),
    Surah(name: "القدر", imageRange: 486..<489),
    Surah(name: "البينة", imageRange: 489..<492),
    Surah(name: "الزلزلة", imageRange: 492..<495),
    Surah(name: "العاديات", imageRange: 495..<498),
    Surah(name: "القارعة", imageRange: 498..<501),
    Surah(name: "التكاثر", imageRange: 501..<504),
    Surah(name: "العصر", imageRange: 504..<506),
    Surah(name: "الهمزة", imageRange: 506..<508),
    Surah(name: "الفيل", imageRange: 508..<510),
    Surah(name: "قريش", imageRange: 510..<512),
    Surah(name: "الماعون", imageRange: 512..<514),
    Surah(name: "الكوثر", imageRange: 514..<516),
    Surah(name: "الكافرون", imageRange: 516..<519),
    Surah(name: "النصر", imageRange: 519..<521),
    Surah(name: "التوبة", imageRange: 521..<523),
    Surah(name: "الشرح", imageRange: 523..<525),
    Surah(name: "الآخِرة", imageRange: 525..<528),
    Surah(name: "الإخلاص", imageRange: 528..<531),
    Surah(name: "الفلق", imageRange: 531..<534),
    Surah(name: "الناس", imageRange: 534..<537)
]

struct ContentView: View {
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    @State private var searchText = ""
    
    var filteredSurahs: [Surah] {
        if searchText.isEmpty {
            return surahs
        } else {
            return surahs.filter { $0.name.contains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // حقل البحث
                TextField("ابحث عن سورة...", text: $searchText)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)
                    .padding()
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(filteredSurahs) { surah in
                            NavigationLink(destination: SurahImageView(surah: surah)) {
                                VStack {
                                    
                                    Image("\(surah.imageRange.lowerBound)")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 100)
                                        .cornerRadius(10)
                                    Text(surah.name)
                                        .font(.custom("Amiri", size: 16))
                                        .multilineTextAlignment(.center)
                                        .padding(.top, 5)
                                }
                                .padding()
                                .background(Color("ButtonBackground"))
                                .cornerRadius(12)
                                .shadow(radius: 5)
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("القرآن الكريم")
        }
    }
}

struct SurahImageView: View {
    let surah: Surah

    var body: some View {
        ScrollView {
            VStack {
                ForEach(surah.imageRange, id: \.self) { pageNumber in
                    Image("\(pageNumber)")
                        .resizable()
                        .scaledToFit()
                        .padding()
                        .border(Color("BorderGold"), width: 5) 
                }
            }
        }
        .background(Color("PageBackground"))
        .navigationTitle(surah.name)
    }
}

#Preview {
    ContentView()
}




//
//
//
//لتنزيل الصور الخاصه بالقران الكريم من خلال هذا الرابط
//
//https://2u.pw/4Km1WBMG
//
